# Kinship — Live Family Tree Application Starter

Java 21, Spring Boot, Thymeleaf, PostgreSQL. Includes a shared database, phone OTP flow, invitation tokens, invitee phone matching, accept/decline workflow, family dashboard, WhatsApp/SMS message links, Docker setup.

## What is implemented
- PostgreSQL-backed users, invitations, and family links.
- Phone OTP login. Development mode logs a temporary OTP to the app logs; this is only for local testing.
- Optional Twilio Verify integration for SMS OTP (`OTP_MODE=twilio`).
- Unique 256-bit random invitation tokens, seven-day expiry, status and response timestamp.
- Acceptance checks that the signed-in phone matches the invited phone.
- WhatsApp click-to-chat and SMS links; user still confirms sending.
- Responsive Thymeleaf interface and health endpoint `/health`.

## Local run (Docker)
1. Install Docker Desktop and ensure it is running.
2. Copy `.env.example` to `.env`, then set a strong `DB_PASSWORD`.
3. Run `docker compose up --build`.
4. Open `http://localhost:8080`.
5. With `OTP_MODE=console`, find the OTP in the app logs:
   `docker compose logs -f app`
6. Sign in with a phone in E.164 format, e.g. `+919876543210`. This development mode does not send SMS.

## Enable real OTP
Create a Twilio Verify service and set `OTP_MODE=twilio`, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_VERIFY_SERVICE_SID` in `.env`. Restart the app. Confirm account permissions, sender configuration, geographic permissions, and pricing in your provider console. Never commit `.env`.

## Before public launch — mandatory
This is a deployment-ready starter, not yet a fully audited production release. Before putting real family data online:
- Deploy behind HTTPS and set `APP_BASE_URL` to the real HTTPS domain.
- Use a managed PostgreSQL service with automated backups and restore testing.
- Move secrets into your host's secret manager.
- Add rate limiting and abuse controls for OTP and invitation creation, plus audit logging and monitoring.
- Configure secure cookies (`Secure` behind HTTPS), review CSRF and security headers, and run dependency/security testing.
- Review data privacy, consent, deletion/export, and retention requirements for family/phone data.
- Configure WhatsApp Business Platform if business-initiated/automated WhatsApp sending is required. `wa.me` links only open a prefilled message and require the sender to press Send.
- Add relationship-direction and family-tree consistency rules for the full tree experience.

## Deploy
Deploy the Docker image to a host supporting Docker and attach a managed PostgreSQL database. Set environment variables from `.env.example` in the hosting dashboard. Use the host's HTTPS domain as `APP_BASE_URL`. This source bundle does not itself create a hosting account, DNS, provider credentials, or a public URL.
