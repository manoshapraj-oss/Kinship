package in.kinship;

import jakarta.servlet.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {
    @Override public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String path=request.getRequestURI();
        if (path.startsWith("/auth/") || path.startsWith("/invite/") || path.equals("/health") || path.startsWith("/css/") || path.startsWith("/js/")) return true;
        if (request.getSession(false)==null || request.getSession(false).getAttribute("userId")==null) {
            response.sendRedirect("/"); return false;
        }
        return true;
    }
}
