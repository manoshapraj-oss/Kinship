package in.kinship;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.constraints.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;

@Controller
public class FamilyController {
    private final UserRepository users;
    private final FamilyLinkRepository links;
    private final InvitationRepository invitations;
    private final OtpService otp;
    @Value("${kinship.base-url:http://localhost:8080}") String baseUrl;
    public FamilyController(UserRepository users, FamilyLinkRepository links, InvitationRepository invitations, OtpService otp) {
        this.users=users; this.links=links; this.invitations=invitations; this.otp=otp;
    }
    record OtpRequest(@NotBlank @Pattern(regexp="^\\+[1-9][0-9]{7,14}$") String phone) {}
    record VerifyRequest(@NotBlank @Pattern(regexp="^\\+[1-9][0-9]{7,14}$") String phone,
                         @NotBlank @Pattern(regexp="^[0-9]{4,8}$") String code, @NotBlank @Size(max=120) String name) {}
    record InviteRequest(@NotBlank @Size(max=120) String name,
                         @NotBlank @Pattern(regexp="^\\+[1-9][0-9]{7,14}$") String phone,
                         @NotBlank @Size(max=60) String relationship) {}

    @GetMapping("/") String index(HttpSession session, Model model) {
        if (session.getAttribute("userId") != null) return "redirect:/dashboard";
        model.addAttribute("csrf", ""); return "login";
    }
    @PostMapping("/auth/request-otp") String requestOtp(@ModelAttribute OtpRequest req, Model model) {
        try { otp.start(req.phone()); model.addAttribute("phone",req.phone()); model.addAttribute("sent",true); }
        catch(Exception e) { model.addAttribute("error","Could not start verification. Please try again."); }
        return "login";
    }
    @PostMapping("/auth/verify-otp") String verifyOtp(@ModelAttribute VerifyRequest req, HttpSession session, Model model) {
        if (!otp.verify(req.phone(),req.code())) {
            model.addAttribute("phone",req.phone()); model.addAttribute("error","The code is invalid or expired. Request a new code."); return "login";
        }
        KinshipUser user=users.findByPhone(req.phone()).orElseGet(()->users.save(new KinshipUser(req.phone(),req.name().trim())));
        if (user.name==null || user.name.isBlank()) user.name=req.name().trim();
        users.save(user);
        session.setAttribute("userId",user.id);
        return "redirect:/dashboard";
    }
    @PostMapping("/auth/logout") String logout(HttpSession session) { session.invalidate(); return "redirect:/"; }

    @GetMapping("/dashboard") String dashboard(HttpSession session, Model model) {
        KinshipUser user=current(session); model.addAttribute("user",user);
        model.addAttribute("members",links.findByFamilyOwnerIdAndStatusOrderByCreatedAtAsc(user.id,"ACCEPTED"));
        model.addAttribute("invitations",invitations.findByInviterIdOrderByCreatedAtDesc(user.id));
        return "dashboard";
    }
    @PostMapping("/invite") String createInvite(@ModelAttribute InviteRequest req, HttpSession session, Model model) {
        KinshipUser user=current(session);
        FamilyInvitation inv=new FamilyInvitation(); inv.inviter=user; inv.inviteeName=req.name().trim(); inv.inviteePhone=req.phone();
        inv.relationship=req.relationship(); inv.token=randomToken(); inv.status="PENDING"; inv.createdAt=Instant.now(); inv.expiresAt=Instant.now().plusSeconds(60L*60*24*7);
        invitations.save(inv);
        model.addAttribute("invite",inv); model.addAttribute("link",baseUrl+"/invite/"+inv.token);
        model.addAttribute("wa","https://wa.me/"+req.phone().substring(1)+"?text="+java.net.URLEncoder.encode("Hello "+req.name()+", "+user.name+" invited you to join their family tree as "+req.relationship()+". Accept the invitation here: "+baseUrl+"/invite/"+inv.token,java.nio.charset.StandardCharsets.UTF_8));
        model.addAttribute("sms","sms:"+req.phone()+"?body="+java.net.URLEncoder.encode("Hello "+req.name()+", "+user.name+" invited you to join their family tree as "+req.relationship()+". Accept here: "+baseUrl+"/invite/"+inv.token,java.nio.charset.StandardCharsets.UTF_8));
        model.addAttribute("user",user);
        model.addAttribute("members",links.findByFamilyOwnerIdAndStatusOrderByCreatedAtAsc(user.id,"ACCEPTED"));
        model.addAttribute("invitations",invitations.findByInviterIdOrderByCreatedAtDesc(user.id));
        model.addAttribute("createdLink",baseUrl+"/invite/"+inv.token);
        model.addAttribute("createdWa",model.getAttribute("wa")); model.addAttribute("createdSms",model.getAttribute("sms"));
        return "dashboard";
    }
    @GetMapping("/invite/{token}") String viewInvite(@PathVariable String token, HttpSession session, Model model) {
        FamilyInvitation inv=invitations.findByToken(token).orElse(null);
        if(inv==null || inv.expiresAt==null || Instant.now().isAfter(inv.expiresAt) || !"PENDING".equals(inv.status)) {
            model.addAttribute("message","This invitation is invalid, expired, or has already been answered."); return "invite";
        }
        model.addAttribute("invite",inv);
        if(session.getAttribute("userId")!=null) model.addAttribute("user",current(session));
        return "invite";
    }
    @PostMapping("/invite/{token}/accept") String accept(@PathVariable String token, HttpSession session, Model model) {
        if(session.getAttribute("userId")==null) { session.setAttribute("pendingInvite",token); return "redirect:/"; }
        KinshipUser user=current(session);
        FamilyInvitation inv=invitations.findByToken(token).orElse(null);
        if(inv==null || inv.expiresAt==null || Instant.now().isAfter(inv.expiresAt) || !"PENDING".equals(inv.status)) {
            model.addAttribute("message","This invitation is invalid, expired, or already answered."); return "invite";
        }
        if(!user.phone.equals(inv.inviteePhone)) { model.addAttribute("message","Please sign in with the mobile number this invitation was sent to."); return "invite"; }
        inv.status="ACCEPTED"; inv.respondedAt=Instant.now(); invitations.save(inv);
        if(links.findByFamilyOwnerIdAndMemberId(inv.inviter.id,user.id).isEmpty()) links.save(new FamilyLink(inv.inviter,user,inv.relationship,"ACCEPTED"));
        if(links.findByFamilyOwnerIdAndMemberId(user.id,inv.inviter.id).isEmpty()) links.save(new FamilyLink(user,inv.inviter,"Family","ACCEPTED"));
        return "redirect:/dashboard";
    }
    @PostMapping("/invite/{token}/decline") String decline(@PathVariable String token, HttpSession session, Model model) {
        FamilyInvitation inv=invitations.findByToken(token).orElse(null);
        if(inv==null || session.getAttribute("userId")==null) { model.addAttribute("message","Please sign in to respond to this invitation."); return "invite"; }
        KinshipUser user=current(session);
        if(!user.phone.equals(inv.inviteePhone)) { model.addAttribute("message","Please sign in with the mobile number this invitation was sent to."); model.addAttribute("invite",inv); return "invite"; }
        inv.status="DECLINED"; inv.respondedAt=Instant.now(); invitations.save(inv);
        model.addAttribute("message","You declined this family invitation."); return "invite";
    }
    @GetMapping("/health") @ResponseBody ResponseEntity<Map<String,String>> health() { return ResponseEntity.ok(Map.of("status","ok","service","kinship")); }
    private KinshipUser current(HttpSession s) { return users.findById((Long)s.getAttribute("userId")).orElseThrow(); }
    private static String randomToken() { byte[] b=new byte[32]; new SecureRandom().nextBytes(b); return Base64.getUrlEncoder().withoutPadding().encodeToString(b); }
}
