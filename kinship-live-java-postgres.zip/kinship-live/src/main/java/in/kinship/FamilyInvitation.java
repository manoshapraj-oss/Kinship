package in.kinship;
import jakarta.persistence.*;
import java.time.Instant;
@Entity
@Table(name="family_invitations", uniqueConstraints=@UniqueConstraint(columnNames="token"))
public class FamilyInvitation {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) public KinshipUser inviter;
 @Column(nullable=false,length=24) public String inviteePhone;
 @Column(nullable=false,length=120) public String inviteeName;
 @Column(nullable=false,length=60) public String relationship;
 @Column(nullable=false,unique=true,length=64) public String token;
 @Column(nullable=false,length=20) public String status="PENDING";
 public Instant createdAt=Instant.now();
 public Instant expiresAt;
 public Instant respondedAt;
 protected FamilyInvitation() {}
}
