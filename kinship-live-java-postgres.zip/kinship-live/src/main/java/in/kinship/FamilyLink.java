package in.kinship;
import jakarta.persistence.*;
import java.time.Instant;
@Entity
@Table(name="family_links")
public class FamilyLink {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @ManyToOne(optional=false) public KinshipUser familyOwner;
 @ManyToOne(optional=false) public KinshipUser member;
 @Column(nullable=false,length=60) public String relationship;
 @Column(nullable=false,length=20) public String status="ACCEPTED";
 public Instant createdAt=Instant.now();
 protected FamilyLink() {}
 public FamilyLink(KinshipUser owner,KinshipUser member,String relationship,String status){this.familyOwner=owner;this.member=member;this.relationship=relationship;this.status=status;}
}
