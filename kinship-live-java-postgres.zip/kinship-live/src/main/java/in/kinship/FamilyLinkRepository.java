package in.kinship;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface FamilyLinkRepository extends JpaRepository<FamilyLink,Long> {
 List<FamilyLink> findByFamilyOwnerIdAndStatusOrderByCreatedAtAsc(Long ownerId,String status);
 Optional<FamilyLink> findByFamilyOwnerIdAndMemberId(Long ownerId,Long memberId);
 List<FamilyLink> findByMemberIdAndStatus(Long memberId,String status);
}
