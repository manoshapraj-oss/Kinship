package in.kinship;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface InvitationRepository extends JpaRepository<FamilyInvitation,Long> {
 Optional<FamilyInvitation> findByToken(String token);
 List<FamilyInvitation> findByInviterIdOrderByCreatedAtDesc(Long inviterId);
 List<FamilyInvitation> findByInviteePhoneOrderByCreatedAtDesc(String inviteePhone);
}
