package in.kinship;
import jakarta.persistence.*;
import java.time.Instant;
@Entity
@Table(name="kinship_users", uniqueConstraints=@UniqueConstraint(columnNames="phone"))
public class KinshipUser {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(nullable=false, unique=true, length=24) public String phone;
 @Column(nullable=false, length=120) public String name;
 public Instant createdAt=Instant.now();
 protected KinshipUser() {}
 public KinshipUser(String phone,String name){this.phone=phone;this.name=name;}
}
