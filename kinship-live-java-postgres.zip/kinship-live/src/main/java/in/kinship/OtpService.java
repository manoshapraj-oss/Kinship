package in.kinship;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Service
public class OtpService {
    @Value("${kinship.otp-mode:console}") String mode;
    @Value("${kinship.twilio-account-sid:}") String accountSid;
    @Value("${kinship.twilio-auth-token:}") String authToken;
    @Value("${kinship.twilio-verify-service-sid:}") String serviceSid;

    public void start(String phone) {
        if ("twilio".equalsIgnoreCase(mode)) {
            requestTwilio(phone, "start");
        } else {
            // Development only. The OTP is printed to the server console and is not sent to a phone.
            String otp = String.format("%06d", new java.security.SecureRandom().nextInt(1_000_000));
            System.out.println("[KINSHIP DEVELOPMENT OTP] " + phone + " => " + otp);
            // Keep it in a short-lived server session through controller.
            OtpSessionStore.put(phone, otp);
        }
    }

    public boolean verify(String phone, String code) {
        if ("twilio".equalsIgnoreCase(mode)) return requestTwilio(phone, "check:" + code);
        return OtpSessionStore.verify(phone, code);
    }

    private boolean requestTwilio(String phone, String action) {
        try {
            boolean checking = action.startsWith("check:");
            String endpoint = "https://verify.twilio.com/v2/Services/" + serviceSid +
                (checking ? "/VerificationCheck" : "/Verifications");
            String form = "To=" + enc(phone) + (checking
                ? "&Code=" + enc(action.substring(6))
                : "&Channel=sms");
            String creds = Base64.getEncoder().encodeToString((accountSid + ":" + authToken).getBytes(StandardCharsets.UTF_8));
            HttpRequest req = HttpRequest.newBuilder(URI.create(endpoint))
                .header("Authorization","Basic "+creds)
                .header("Content-Type","application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form)).build();
            HttpResponse<String> response = HttpClient.newHttpClient().send(req,HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) return false;
            if (checking) return response.body().contains("\\"status\\": \\"approved\\"") || response.body().contains("\\"status\\":\\"approved\\"");
            return true;
        } catch (Exception ex) {
            System.err.println("OTP provider error: " + ex.getMessage());
            return false;
        }
    }
    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
