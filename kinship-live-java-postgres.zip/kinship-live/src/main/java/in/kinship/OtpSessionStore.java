package in.kinship;

import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;

final class OtpSessionStore {
    private record Entry(String code, Instant expiresAt, int attempts) {}
    private static final ConcurrentHashMap<String,Entry> OTP = new ConcurrentHashMap<>();
    static void put(String phone, String code) { OTP.put(phone,new Entry(code,Instant.now().plusSeconds(300),0)); }
    static boolean verify(String phone, String code) {
        Entry e=OTP.get(phone);
        if(e==null || Instant.now().isAfter(e.expiresAt()) || e.attempts()>=5) { OTP.remove(phone); return false; }
        if(e.code().equals(code)) { OTP.remove(phone); return true; }
        OTP.put(phone,new Entry(e.code(),e.expiresAt(),e.attempts()+1)); return false;
    }
    private OtpSessionStore() {}
}
