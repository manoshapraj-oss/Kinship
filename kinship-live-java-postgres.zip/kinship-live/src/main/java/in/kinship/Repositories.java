package in.kinship;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

interface UserRepository extends JpaRepository<KinshipUser,Long> {
    Optional<KinshipUser> findByPhone(String phone);
}
interface FamilyLinkRepository extends JpaRepository<FamilyLink,Long> {
    List<FamilyLink> findByFamilyOwnerIdAndStatusOrderByCreatedAtAsc(Long ownerId, String status);
    Optional<FamilyLink> findByFamilyOwnerIdAndMemberId(Long ownerId, Long memberId);
    List<FamilyLink> findByMemberIdAndStatus(Long memberId, String status);
}
interface InvitationRepository extends JpaRepository<FamilyInvitation,Long> {
    Optional<FamilyInvitation> findByToken(String token);
    List<FamilyInvitation> findByInviterIdOrderByCreatedAtDesc(Long inviterId);
    List<FamilyInvitation> findByInviteePhoneOrderByCreatedAtDesc(String inviteePhone);
}
