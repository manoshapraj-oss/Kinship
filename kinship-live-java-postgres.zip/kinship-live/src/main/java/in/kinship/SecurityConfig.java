package in.kinship;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
    @Bean SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // App routes use session-based OTP authentication via AuthInterceptor; CSRF remains enabled.
        return http.authorizeHttpRequests(a -> a.anyRequest().permitAll())
            .csrf(Customizer.withDefaults())
            .headers(h -> h.frameOptions(f -> f.deny()).contentTypeOptions(Customizer.withDefaults()))
            .build();
    }
}
